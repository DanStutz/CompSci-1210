#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Given a list, L, of nonnegative integers return a tuple consisting
# of max copies of min and min copies of max, where max and min are
# the largest and smallest elements of L, respectively.
def minByMax(L):
    return((min(L),)*max(L) + (max(L),)*min(L))

######################################################################
# Given two strings, S and U, and two integers, 0 <= i, j < len(S),
# return a new copy of S that replaces S[i:j] with U.
def insertString(S, i, j, U):
    return(S[:i] + U + S[j:])

######################################################################
# Given a sequence, S, return a list containing the unique elements of
# S in arbitrary order.
def findUnique(S):
    return(list(set(S)))

######################################################################
# Given a list, L, and a nonnegative integer k, modify L by replacing
# the centermost element of L with k 0's. This version creates an
# entirely new list, so that the original list L is unmodified.
def inflateCenter(L, k):
    return(L[:len(L)//2] + [0]*k + L[len(L)//2+1:])

######################################################################
# Given a list, L, and a nonnegative integer k, modify L by replacing
# the centermost element of L with k 0's. This version modifies the
# original list (lists are mutable).
def inflateCenter(L, k):
    L[(len(L)//2):len(L)//2+1] = [0]*k
    return(L)

