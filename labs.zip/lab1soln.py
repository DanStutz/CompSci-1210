#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Convert Farenheit to Celsius
def f2c(t):
    return((5/9)*(t-32))

# Convert Celsius to Farenheit
def c2f(t):
    return(((9/5)*t)+32)

######################################################################
# Convert Celsius to Kelvin
def c2k(t):
    return(t+273.15)

# Convert Kelvin to Celsius
def k2c(t):
    return(t-273.15)

# Convert Kelvin to Farenheit
def k2f(t):
    return(((9/5)*(t-273.15))+32)

# Convert Farenheit to Kelvin
def f2k(t):
    return(((5/9)*(t-32))+273.15)

# Convert Delisle to Celsius
def d2c(t):
    return(100-(2/3)*t)

# Convert Celsius to Delisle
def c2d(t):
    return((3/2)*(100-t))

# Convert Delisle to Farenheit
def d2f(t):
    return(((9/5)*(100-(2/3)*t))+32)

# Convert Farenheit to Delisle
def f2d(t):
    return((3/2)*(100-((5/9)*(t-32))))

# Convert Delisle to Kelvin
def d2k(t):
    return(373.15-(2/3)*t)

# Convert Kelvin to Delisle
def k2d(t):
    return((3/2)*(100-(t-273.15)))
