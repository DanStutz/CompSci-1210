#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Superdigit!
def superdigit(N):
    # Base case: single digit number.
    if N<10:
        return(N)
    # Recursive step: sum current digits (which may be > 9).
    return(superdigit(sum([ int(x) for x in list(str(N)) ])))

def superdigit(N):
    # Base case: single digit number.
    if N<10:
        return(N)
    # Recursive step: collapse the ones position.
    return(superdigit(N//10 + N%10))

######################################################################
# Sum elements of a list.
def supersum(L):
    # Two base cases: the empty list and an element that is not a list.
    if L==[]:
        return(0)
    elif not isinstance(L, list):
        return(L)
    # Recursive step: add sum of head with sum of rest of list.
    return(supersum(L[0]) + supersum(L[1:]))

def supersum(L, S=0):
    # Two base cases: the empty list and an element that is not a list.
    if L==[]:
        return(S)
    elif not isinstance(L, list):
        return(S+L)
    # Recursive step: add sum of head with sum of rest of list.
    return(supersum(L[0], S) + supersum(L[1:], S))

def supersum(L, F=[]):
    S = 0
    F.extend(L)
    while len(F) > 0:
        e=F.pop()
        if not isinstance(e, list):
            S += e
        else:
            F.extend(e)
    return(S)

######################################################################
# Flatten a list.
def superlist(L):
    # Two base cases: the empty list and a non-list.
    if L==[]:
        return(L)
    elif not isinstance(L, list):
        return([L])
    # Recursive step: flatten the head and concatenate the flattened tail.
    return(superlist(L[0]) + superlist(L[1:]))

def superlist(L, R=[]):
    # Two base cases: the empty list and a non-list.
    if L==[]:
        return(R)
    elif not isinstance(L, list):
        return(R + [L])
    # Recursive step: flatten the head and concatenate the flattened tail.
    return(superlist(L[1:], R + superlist(L[0])))

