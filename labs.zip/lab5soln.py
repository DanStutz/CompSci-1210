#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Comparison function. Returns True if x<y.
def lt(x, y):
    return(x<y)

# Comparison function. Returns True if x>y.
def gt(x, y):
    return(x>y)

# Comparison function. Returns True if len(x)<len(y) or x<y if same
# length.
def shorter(x, y):
    return(len(x) < len(y) or (len(x) == len(y) and x < y))

# Comparison function. Returns True if len(x)>len(y) or x<y if same
# length.
def longer(x, y):
    return(len(x) > len(y) or (len(x) == len(y) and x < y))

# Returns the k ``best'' elements of list L according to the specified
# comparison function. Modifies L (lists are mutable).
def bestKofN(L, k, fn = lt):
    def findBest(L):
        best = 0
        for i in range(len(L)):
            if fn(L[i],L[best]):
                best = i
        print("Finding best of {} => {}".format(L, best))
        return(best)
    for i in range(min(k,len(L)-1)):
        best = findBest(L[i:])
        L[i],L[i+best] = L[i+best],L[i]
        print("List updated => {}".format(L))
    return(L[:k])
