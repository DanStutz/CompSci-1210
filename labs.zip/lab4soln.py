#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Homework 1 stuff.
#
# Read in a book from a file and return a single string containing the
# entire book with front matter, chapter headers, and blank lines
# removed.
def getBook(file):
    # Read in the file.
    with open(file, 'r') as f:
        book = f.read()
        # Get rid of blank lines or lines containing ALL CAPS, flusing
        # newlines as you go.
    book = ' '.join([ line for line in book.split('\n') if len(line.strip()) > 0 and line.upper() != line ])
    # Return book
    return(book)

######################################################################
# Remove possessives and flush extra punctuation from a string of text
# like that returned by getBook(). The process will certainly affect
# readability but not word order or sentence structure (except by
# promoting parenthetical remarks).
#
# Good additions might be: ("n't "," not")
def cleanup(text):
    # Remove possessives, flush characters in ',:;\'"()', replace '-'
    # with space and '!?' with '.'.
    for substitution in (("'s ", ' '),('(', ''),(')', ''),(',',''),(':',''),(';',''),('\'',''),('"',''),('-',' '),('_',' '),('?','.'),('!','.')):
        text = text.replace(substitution[0], substitution[1])
    # Return text
    return(text)

######################################################################
# Return an ordered list of words (lowercase) from a string of text
# like that returned by cleanup().
def extractWords(text):
    # Break remaining text up into words.
    return( text.replace('.','').lower().split() )

######################################################################
# Returns the number of syllables in the specified word. Syllables are
# defined according to a few simple rules:
#   1. flush trailing -s and -e
#   2. each syllable starts with a vowel
#   3. y is a vowel when it follows a consonant
#   4. every word has at least one syllable
def HW1countSyllables(word):
    # Figure effective length of the word.
    length = len(word)
    if word[-1]=='s' or word[-1]=='e':
        length = length-1
    # Start at the beginning of the word and flush any leading consonants.
    i = 0
    while i < length and word[i].lower() not in 'aeiouy':
        i = i+1
    # Start counting syllables, starting with the first vowel or y (a
    # vowel in this context).
    s = 0
    while i < length:
        s = s+1
        # A y here is a vowel.
        if word[i].lower() == 'y':
            i = i+1
        # A y here is a consonant; skip other vowels.
        while i < length and word[i].lower() in 'aeiou':
            i = i+1
        # Skip consonants if there is any word left, stopping at first
        # vowel+y. Must skip at least one consonant to consider y a
        # vowel again.
        if i < length:
            i = i+1   # A non-y consonant.
        while i < length and word[i].lower() not in 'aeiouy':
            i = i+1
    return(max(s,1))

######################################################################
# Determine if the ith character of word w is a vowel; returns
# True/False. Rules for determining if a character is a vowel are:
#     aeio are vowels;
#     y is a vowel unless it is the first letter of the word;
#     u is a vowel unless it follows g or q; and
#     w is a vowel when it follows a vowel.
# Note: this problem originally read
#     y is a vowel unless it follows a vowel; 
# hence the extra commented-out elif.
def isVowel(word, i):
    if word[i] in 'aeio':
        return(True)
    elif word[i] in 'y' and i!=0:
        return(True)
#    elif word[i] in 'y' and (i!=0 and not isVowel(word, i-1)):
#        return(True)
    elif word[i] in 'u' and (i==0 or word[i-1] not in 'gq'):
        return(True)
    elif word[i] in 'w' and (i!=0 and isVowel(word, i-1)):
        return(True)        
    else:
        return(False)

######################################################################
# Count the number of syllables in a given word. A syllable is a
# maximally long sequence of vowels followed by a maximally long
# sequence of consonants; note that you must flush any leading
# consonants (these do not constitute a complete syllable) and ignore
# syllables consisting of only vowels unless it is a single 'y'.
def countSyllables(word):
    word=word.lower()
    if len(word) <= 3:
        return(1)
    elif word[-2:] == 'es' or word[-2:] == 'ed':
        length = len(word)-2
    elif word[-1] == 'e' and word[-2] != 'l':
        length = len(word)-1
    else:
        length = len(word)
    # Flush any leading consonants.
    s = i = 0
    while i < length and not isVowel(word, i):
        i = i+1
    while i < length:
        # Consume as many vowels as possible.
        while i < length and isVowel(word, i):
            i = i+1
        # Consume as many consonants as possible.
        while i < length and not isVowel(word, i):
            i = i+1
        # Increment syllable count.
        s = s+1
    return(s)
