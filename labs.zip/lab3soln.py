#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Given a sequence of integers, S, and an integer radix r, return a
# list containing the integers of S rounded up to the next larger
# multiple of r.
def roundUp(S, r):
    return([ x+(r-x%r) for x in S ])

######################################################################
# Given a string, S, representing a set of words separated by spaces,
# return the ratio of non-space characters to the length of S.
def wordRatio(S):
    return(sum([ len(w) for w in S.split() ])/len(S))

######################################################################
# Given a string, S, representing a set of words separated by spaces,
# return a dictionary where each word in S is a key and the number of
# vowels (defined as a, e, i, o or u) in that word is the value.
def vcDict(S):
    return({ w:len([ c for c in w if c.lower() in 'aeiou' ]) for w in S.split() })

######################################################################
# Given an integer, k, return a tuple containing all triples (x, y, z)
# where 0 < x,y,z < k and x < y < z.
def allTriples(k):
    return(tuple([ (x, y, z) for x in range(k) for y in range(k) for z in range(k) if x > y > z ]))
