#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre", ))

######################################################################
import csv
from math import sqrt

######################################################################
# We'll represent vectors as lists of numbers; we'll define the vector
# class as a specialization of list so that we can handle
# normalization and dotproduct.

# This class is a bit odd, because I want to show off an argument
# handling trick. We'll make the vector constructor different from the
# list constructor by grouping all the arguments given into a new
# list. This means Vector(1,2,3,4) will return a 4-element vector
# <1,2,3,4>, even though list(1,2,3,4) does not (the correct form is
# list([1,2,3,4]), which returns [1,2,3,4]). This isn't necessarily a
# good idea, but grouping multiple remaining arguments with the *args
# construct is a good trick to know about.

# Also, I use zip() to "sew" to lists together, element by element, so
# zip([1,2,3],[4,5,6]) yields a zip object that looks internally like
# [(1, 4), (2, 5), (3, 6)]. To unzip: zip(*zip([1,2,3],[4,5,6])).
# Note zip() is handy for transposing matrices!
class Vector(list):
    def __init__(self, *args):
        '''Constructor invokes list constructor on the collection of args given.'''
        list.__init__(self, list(args))

    def __repr__(self):
        '''Replace standard list brackets with angle brackets.'''
        S = list.__repr__(self)
        return('<{0}>'.format(S[1:len(S)-1]))

    def magnitude(self):
        '''Returns scalar magnitude of self.'''
        return(sqrt(sum([ val*val for val in self ])))

    def normalize(self):
        '''Normalize self to unit magnitude. Returns True on success, False
           otherwise.'''
        mag = self.magnitude()
        if mag == 0:
            return(False)
        for i in range(len(self)):
            self[i] = self[i]/mag
        return(True)

    # Note use of zip() to simplify the code.
    def dproduct(self, other):
        '''Dot product of self and another vector.'''
        return(sum([ pair[0]*pair[1] for pair in zip(self,other) ]))

    def edistance(self, other):
        '''Euclidean distance between two vectors.'''
        return(sqrt(sum([ pow(pair[0]-pair[1],2) for pair in zip(self,other) ])))
