#!/usr/local/anaconda/bin/python
# Alberto Maria Segre
# CS:1210:0AAA

######################################################################
# This function returns your hawkid for the autograder.
def hawkid():
    return(("segre",))

######################################################################
# Instances of type Student represent individual students.
class Student():
    def __init__(self, name):
        self.name = name
        self.transcript = {}

    # Simplify what gets printed.
    def __repr__(self):
        return('<Student: {}>'.format(self.name))

    ##################################################################
    # Manipulate the student's transcript to reflect enrollment.
    def enroll(self, c):
        self.transcript[c]='I'

    ##################################################################
    # Manipulate the student's transcript to reflect withdrawl.
    def drop(self, c):
        if c in self.transcript:
            self.transcript[c]='W'

######################################################################
# Instances of type Class represent individual courses.
class Class():
    def __init__(self, name, sch = 3, cap = 30):
        self.name = name
        self.sch = sch
        self.cap = cap
        self.roster = {}
        self.waitlist = []

    # Simplify what gets printed.
    def __repr__(self):
        return('<Class: {}>'.format(self.name))

    ##################################################################
    # Method to enroll given student in this class. Make sure you
    # don't exceed the course enrollment cap; you'll need to check the
    # roster for students still marked active. Any student attempting
    # to enroll beyond the cap should be added to the course waitlist
    # instead. Important: once enrolled, make sure you invoke the
    # Student.enroll() method to update the student object as well.
    def enroll(self, student):
        if len([s for s in self.roster if self.roster[s]]) < self.cap and student not in self.roster:
            self.roster[student] = {}
            self.roster[student] = True
            student.enroll(self)
            return(True)
        else:
            self.waitlist.append(student)
        return(False)

    ##################################################################
    # Method to drop given student in this class. If there are
    # students still on the waitlist, they should be automatically
    # enrolled. Students who drop should remain on the roster but
    # should be marked inactive. Important: once withdrawn, make sure
    # you invoke the Student.drop() method to update the student
    # object as well.
    def drop(self, student):
        if student in self.roster and self.roster[student] == True:
            self.roster[student] = False
            student.drop(self)
            if self.waitlist:
                self.enroll(self.waitlist.pop(0))
            return(True)
        return(False)
